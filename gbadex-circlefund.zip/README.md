# Gbadex CircleFund

A thrift contribution platform built with MERN stack.