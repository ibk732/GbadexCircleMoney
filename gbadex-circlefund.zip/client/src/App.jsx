import React from 'react';

function App() {
  return <div>Welcome to Gbadex CircleFund</div>;
}

export default App;